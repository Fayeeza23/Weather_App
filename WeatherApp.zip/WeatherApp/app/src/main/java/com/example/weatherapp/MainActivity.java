package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    EditText place;
    String city;

    static TextView temp;
    static TextView temp1;
    static TextView temp2;
    static TextView temp3;
    static TextView temp4;
    static TextView temp5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        place =(EditText) findViewById(R.id.place);
        temp=(TextView) findViewById(R.id.temp);
        temp1=(TextView) findViewById(R.id.temp1);
        temp2=(TextView) findViewById(R.id.temp2);
        temp3=(TextView) findViewById(R.id.temp3);
        temp4=(TextView) findViewById(R.id.temp4);
        temp5=(TextView) findViewById(R.id.temp5);


//        Weather metadata= new Weather();
////        metadata.execute("https://api.openweathermap.org/data/2.5/weather?q=Dhaka&appid=8ed05bb1456f074f76f54515eae8f3ff&units=metric");
//        metadata.execute("https://api.openweathermap.org/data/2.5/forecast?q=Dhaka&appid=8ed05bb1456f074f76f54515eae8f3ff&units=metric");
    }

    public void Show(View view) {
        city=place.getText().toString();

        Weather metadata= new Weather();
//        metadata.execute("https://api.openweathermap.org/data/2.5/weather?q=Dhaka&appid=8ed05bb1456f074f76f54515eae8f3ff&units=metric");
        metadata.execute("https://api.openweathermap.org/data/2.5/forecast?q="+city+"&appid=8ed05bb1456f074f76f54515eae8f3ff&units=metric");

    }

}
