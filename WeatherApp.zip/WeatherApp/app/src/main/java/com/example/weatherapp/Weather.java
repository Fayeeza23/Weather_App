package com.example.weatherapp;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Weather extends AsyncTask<String, Void, String> {
    String result;

    @Override
    protected String doInBackground(String... urls) {
        result = "";
        URL link;
        HttpURLConnection myConnection = null;

        try {
            link = new URL(urls[0]);
            myConnection = (HttpURLConnection) link.openConnection();
            InputStream in = myConnection.getInputStream();
            InputStreamReader myStreamReader = new InputStreamReader(in);
            int data = myStreamReader.read();
            while (data != -1) {
                char current = (char) data;
                result += current;
                data = myStreamReader.read();
            }
            return result;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

//        try {

//
//            JSONObject myObject = new JSONObject(result);
//            JSONObject main = new JSONObject(myObject.getString("main"));
//            String temperature = main.getString("temp");
//            String placeName = myObject.getString("name");
//
//            MainActivity.place.setText(placeName);
//            MainActivity.temp.setText(temperature);
//            MainActivity.temp.setText(result);
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//    }
        try{

            JSONObject myObject = new JSONObject(result);
            JSONArray jsonArray = myObject.getJSONArray("list");
            JSONObject jsonObject = jsonArray.getJSONObject(0);

            JSONObject main = new JSONObject(jsonObject.getString("main"));
            String temp = main.getString("temp");
            String temp_min = main.getString("temp_min");
            String temp_max = main.getString("temp_max");
            String humidity = main.getString("humidity");

            JSONObject wind = new JSONObject(jsonObject.getString("wind"));
            String speed = wind.getString("speed");

                JSONArray W = new JSONArray(jsonObject.getString("weather"));
                JSONObject Weather= W.getJSONObject(0);
                String weather= Weather.getString("main");

            MainActivity.temp.setText("Now = " + temp + " °C" + "\n" + "Min = " + temp_min + " °C" + "\n" + "Max = " + temp_max + " °C"
                    + "\n" + "Humidity = " + humidity
                    + "\n" + "Wind = " + speed + "Km/h"+"\n"+"Weather = " +weather);

//////////////////////////////////////////////////////////////////////////////////////////////////////

            JSONObject jsonObject1 = jsonArray.getJSONObject(1);
            JSONObject main1 = new JSONObject(jsonObject1.getString("main"));
            String temp1 = main1.getString("temp");
            String temp_min1 = main1.getString("temp_min");
            String temp_max1 = main1.getString("temp_max");
            String humidity1 = main1.getString("humidity");

            JSONObject wind1 = new JSONObject(jsonObject1.getString("wind"));
            String speed1 = wind1.getString("speed");


            JSONArray W1 = new JSONArray(jsonObject1.getString("weather"));
            JSONObject Weather1= W1.getJSONObject(0);
            String weather1= Weather1.getString("main");

            MainActivity.temp1.setText("Now = " + temp1 + " °C" + "\n" + "Min = " + temp_min1 + " °C" + "\n" + "Max = " + temp_max1 + " °C"
                    + "\n" + "Humidity = " + humidity1
                    + "\n" + "Wind = " + speed1 + "Km/h"+"\n"+"Weather = " + weather1);
///////////////////////////////////////////////////////////////////////////////////////////////////////




            JSONObject jsonObject2 = jsonArray.getJSONObject(2);
            JSONObject main2 = new JSONObject(jsonObject2.getString("main"));
            String temp2 = main2.getString("temp");
            String temp_min2 = main2.getString("temp_min");
            String temp_max2 = main2.getString("temp_max");
            String humidity2 = main2.getString("humidity");

            JSONObject wind2 = new JSONObject(jsonObject2.getString("wind"));
            String speed2 = wind2.getString("speed");


            JSONArray W2 = new JSONArray(jsonObject.getString("weather"));
            JSONObject Weather2= W2.getJSONObject(0);
            String weather2= Weather2.getString("main");

            MainActivity.temp2.setText("Now = " + temp2 + " °C" + "\n" + "Min = " + temp_min2 + " °C" + "\n" + "Max = " + temp_max2 + " °C"
                    + "\n" + "Humidity = " + humidity2
                    + "\n" + "Wind = " + speed2 + "Km/h"+"\n"+"Weather = " +weather2);

////////////////////////////////////////////////////////////////////////////////////////////////////////



            JSONObject jsonObject3 = jsonArray.getJSONObject(3);
            JSONObject main3 = new JSONObject(jsonObject3.getString("main"));
            String temp3 = main3.getString("temp");
            String temp_min3 = main3.getString("temp_min");
            String temp_max3 = main3.getString("temp_max");
            String humidity3 = main3.getString("humidity");

            JSONObject wind3 = new JSONObject(jsonObject3.getString("wind"));
            String speed3 = wind3.getString("speed");

            JSONArray W3 = new JSONArray(jsonObject3.getString("weather"));
            JSONObject Weather3= W3.getJSONObject(0);
            String weather3= Weather3.getString("main");

            MainActivity.temp3.setText("Now = " + temp3 + " °C" + "\n" + "Min = " + temp_min3 + " °C" + "\n" + "Max = " + temp_max3 + " °C"
                    + "\n" + "Humidity = " + humidity3
                    + "\n" + "Wind = " + speed3 + "Km/h"+"\n"+"Weather = " +weather3);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            JSONObject jsonObject4 = jsonArray.getJSONObject(4);
            JSONObject main4 = new JSONObject(jsonObject4.getString("main"));
            String temp4 = main4.getString("temp");
            String temp_min4 = main4.getString("temp_min");
            String temp_max4 = main4.getString("temp_max");
            String humidity4 = main4.getString("humidity");

            JSONObject wind4 = new JSONObject(jsonObject4.getString("wind"));
            String speed4 = wind4.getString("speed");

            JSONArray W4 = new JSONArray(jsonObject4.getString("weather"));
            JSONObject Weather4= W4.getJSONObject(0);
            String weather4= Weather4.getString("main");


            MainActivity.temp4.setText("Now = " + temp4 + " °C" + "\n" + "Min = " + temp_min4 + " °C" + "\n" + "Max = " + temp_max4 + " °C"
                    + "\n" + "Humidity = " + humidity4
                    + "\n" + "Wind = " + speed4 + "Km/h"+"\n"+"Weather = " +weather4);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            JSONObject jsonObject5 = jsonArray.getJSONObject(5);
            JSONObject main5 = new JSONObject(jsonObject5.getString("main"));
            String temp5 = main5.getString("temp");
            String temp_min5 = main5.getString("temp_min");
            String temp_max5 = main5.getString("temp_max");
            String humidity5 = main5.getString("humidity");

            JSONObject wind5 = new JSONObject(jsonObject5.getString("wind"));
            String speed5 = wind5.getString("speed");

            JSONArray W5 = new JSONArray(jsonObject5.getString("weather"));
            JSONObject Weather5= W5.getJSONObject(0);
            String weather5= Weather5.getString("main");


            MainActivity.temp5.setText("Now = " + temp5 + " °C" + "\n" + "Min = " + temp_min5 + " °C" + "\n" + "Max = " + temp_max5 + " °C"
                    + "\n" + "Humidity = " + humidity5
                    + "\n" + "Wind = " + speed5 + "Km/h"+"\n"+"Weather = " +weather5);

        }
        catch (JSONException e) {
            e.printStackTrace();
        }

    }
}



